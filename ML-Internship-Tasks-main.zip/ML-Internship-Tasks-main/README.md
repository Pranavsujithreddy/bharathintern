# ML-Internship-Tasks
# A virtual internship program by Bharat Intern 

Task 1 : House price prediction <br>
Task 2 : Wine quality prediction<br>
Task 3 : Iris flower classification<br>

contains jupyter notebook with dataset
